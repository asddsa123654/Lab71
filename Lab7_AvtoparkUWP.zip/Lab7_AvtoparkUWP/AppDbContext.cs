using Microsoft.EntityFrameworkCore;

namespace Lab7_AvtoparkUWP
{
    public class AppDbContext : DbContext
    {
        public DbSet<Computer> Computers { get; set; }
        public DbSet<Car> Cars { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=uwpapp.db");
        }
    }
}
