namespace Lab7_AvtoparkUWP
{
    public class Computer
    {
        public int ComputerId { get; set; }
        public string Name { get; set; }
        public string IP { get; set; }
        public string OperatingSystem { get; set; }
        public DateTime PurchaseDate { get; set; }
        public bool IsAssigned { get; set; }
    }
}
