using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using System.Linq;

namespace Lab7_AvtoparkUWP
{
    public sealed partial class MainPage : Page
    {
        private AppDbContext _dbContext;

        public MainPage()
        {
            this.InitializeComponent();
            _dbContext = new AppDbContext();
            _dbContext.Database.EnsureCreated();
            LoadCars();
        }

        private void LoadCars()
        {
            CarListView.ItemsSource = _dbContext.Cars.OrderBy(c => c.Brand).ToList();
        }

        private void AddCar_Click(object sender, RoutedEventArgs e)
        {
            var newCar = new Car { Brand = "Audi", Model = "A4", Year = 2020, Status = "Available" };
            _dbContext.Cars.Add(newCar);
            _dbContext.SaveChanges();
            LoadCars();
        }

        private void EditCar_Click(object sender, RoutedEventArgs e)
        {
            if (CarListView.SelectedItem is Car selectedCar)
            {
                selectedCar.Status = "Unavailable";
                _dbContext.SaveChanges();
                LoadCars();
            }
        }

        private void DeleteCar_Click(object sender, RoutedEventArgs e)
        {
            if (CarListView.SelectedItem is Car selectedCar)
            {
                _dbContext.Cars.Remove(selectedCar);
                _dbContext.SaveChanges();
                LoadCars();
            }
        }
    }
}
